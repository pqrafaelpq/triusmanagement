﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kifome.Classes;
using System.Data;

namespace kifome.Persistencia
{
    /// <summary>
    /// Descrição resumida de CarrinhoBD
    /// </summary>
    public class CarrinhoBD
    {
        //métodos

        //insert
       
        //selectall
        
        //select

        //update

        //delete

        //construtor





        public CarrinhoBD()
        {
            //
            // TODO: Adicionar lógica do construtor aqui
            //
        }
    }
}